from facenet_pytorch import MTCNN, InceptionResnetV1
import torch
from torchvision import datasets
from torch.utils.data import DataLoader
import os

# Initialize MTCNN and InceptionResnetV1 for face detection and embedding
mtcnn0 = MTCNN(image_size=240, margin=0, keep_all=False, min_face_size=40)
resnet = InceptionResnetV1(pretrained='vggface2').eval()

# Check if embeddings already saved
if not os.path.exists('./data.pt'):
    dataset = datasets.ImageFolder('photos')  # Load images from photos folder
    idx_to_class = {i: c for c, i in dataset.class_to_idx.items()}  # map indices to class names

    def collate_fn(x):
        return x[0]

    loader = DataLoader(dataset, collate_fn=collate_fn)

    name_list = []       # names for each embedding
    embedding_list = []  # embeddings list

    for img, idx in loader:
        face, prob = mtcnn0(img, return_prob=True)
        if face is not None and prob > 0.92:
            emb = resnet(face.unsqueeze(0))
            embedding_list.append(emb.detach())
            name_list.append(idx_to_class[idx])

    data = [embedding_list, name_list]
    torch.save(data, 'data.pt')  # save embeddings and names

print("Embeddings generated and saved in data.pt")
import pandas as pd

def monthly_attendance_report(file_path, year, month):
    # Read the attendance CSV file
    df = pd.read_csv(file_path)
    
    # Ensure 'Date' column is datetime type
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Filter records matching the year and month
    monthly_data = df[(df['Date'].dt.year == year) & (df['Date'].dt.month == month)]
    
    # Group by Name and count unique dates (days present)
    summary = monthly_data.groupby('Name')['Date'].nunique().reset_index()
    summary.rename(columns={'Date': 'Days Present'}, inplace=True)
    
    return summary

def main():
    attendance_file = 'attendance_log.csv'
    
    # Get user input for year and month
    while True:
        try:
            year = int(input("Enter year (e.g., 2025): "))
            if year < 1900 or year > 2100:
                raise ValueError
            break
        except ValueError:
            print("Please enter a valid year between 1900 and 2100.")
    
    while True:
        try:
            month = int(input("Enter month (1-12): "))
            if month < 1 or month > 12:
                raise ValueError
            break
        except ValueError:
            print("Please enter a valid month (1 to 12).")
    
    summary = monthly_attendance_report(attendance_file, year, month)
    print(f"\nAttendance Summary for {year}-{month:02d}:\n")
    print(summary)

if __name__ == "__main__":
    main()

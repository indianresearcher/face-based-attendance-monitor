import cv2
import os
import time

def register_user():
    cam = cv2.VideoCapture(0)
    user_name = input("Enter the name of the user to register: ")

    save_path = f'photos/{user_name}'
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    img_count = 0
    print("Capturing images. Press SPACE to capture, ESC to exit.")

    while True:
        ret, frame = cam.read()
        if not ret:
            print("Failed to grab frame")
            break

        cv2.imshow("Register User", frame)

        k = cv2.waitKey(1)
        if k%256 == 27:
            print("ESC pressed. Closing...")
            break
        elif k%256 == 32:
            img_name = f"{save_path}/{int(time.time())}.jpg"
            cv2.imwrite(img_name, frame)
            print(f"Image saved: {img_name}")
            img_count += 1

    cam.release()
    cv2.destroyAllWindows()
    print(f"Total images captured for {user_name}: {img_count}")

if __name__ == "__main__":
    register_user()
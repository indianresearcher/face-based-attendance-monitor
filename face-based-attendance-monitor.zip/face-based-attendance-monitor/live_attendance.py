from facenet_pytorch import MTCNN, InceptionResnetV1
import torch
import cv2
import os
import pandas as pd
from PIL import Image
from datetime import datetime  # <-- Important fix

# Initialize MTCNN for face detection and InceptionResnetV1 for embeddings
mtcnn = MTCNN(image_size=240, margin=0, keep_all=True, min_face_size=40)
resnet = InceptionResnetV1(pretrained='vggface2').eval()

# Load embeddings and names saved from training
data = torch.load('data.pt')
embedding_list = data[0]
name_list = data[1]

attendance_file = 'attendance_log.csv'

# Create CSV if it doesn't exist, with columns 'Name', 'Date', 'Time'
if not os.path.exists(attendance_file):
    df = pd.DataFrame(columns=['Name', 'Date', 'Time'])
    df.to_csv(attendance_file, index=False)

def mark_attendance(name):
    # Read existing CSV or create empty DataFrame if file empty or missing
    try:
        df = pd.read_csv(attendance_file)
    except pd.errors.EmptyDataError:
        df = pd.DataFrame(columns=['Name', 'Date', 'Time'])

    now = datetime.now()
    current_date = now.strftime('%Y-%m-%d')
    current_time = now.strftime('%H:%M:%S')

    # Make sure 'Date' column exists (in case of old or corrupted files)
    if 'Date' not in df.columns:
        df['Date'] = ''

    # Mark attendance only if name and date combination not already present
    if not ((df['Name'] == name) & (df['Date'] == current_date)).any():
        new_entry = {'Name': name, 'Date': current_date, 'Time': current_time}
        df = pd.concat([df, pd.DataFrame([new_entry])], ignore_index=True)
        df.to_csv(attendance_file, index=False)
        print(f'{name} marked present at {current_date} {current_time}')

# Start webcam capture
cam = cv2.VideoCapture(0)

while True:
    ret, frame = cam.read()
    if not ret:
        print("Failed to grab frame")
        break

    img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    faces, probs = mtcnn(img, return_prob=True)

    if faces is not None:
        boxes, _ = mtcnn.detect(img)

        for i, prob in enumerate(probs):
            if prob > 0.90:
                emb = resnet(faces[i].unsqueeze(0)).detach()

                distances = [torch.dist(emb, db_emb).item() for db_emb in embedding_list]
                min_dist = min(distances)
                min_idx = distances.index(min_dist)

                if min_dist < 1.0:  # threshold for matching
                    name = name_list[min_idx]
                    mark_attendance(name)

                    box = [int(b) for b in boxes[i]]
                    cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), (0, 255, 0), 2)
                    cv2.putText(frame, name, (box[0], box[1] - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow("Live Attendance", frame)

    if cv2.waitKey(1) & 0xFF == 27:  # ESC to quit
        print("Exiting...")
        break

cam.release()
cv2.destroyAllWindows()